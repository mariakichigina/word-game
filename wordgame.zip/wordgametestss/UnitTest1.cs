﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Windows;
using System.Windows.Controls;
using WordGame; // Пространство имен вашего проекта

namespace wordgametestss
{
    [TestClass]
    public class MainPageTests
    {
        [TestMethod]
        public void StartButton_ShouldOpenGamePage()
        {
            // Arrange
            var mainWindow = new MainWindow();
            mainWindow.Show(); // Открываем окно, чтобы оно стало активным

            // Ищем кнопку "Начать игру" на главной странице
            var startButton = mainWindow.FindName("StartGame_Click") as Button;

            Assert.IsNotNull(startButton, "Кнопка 'Начать игру' не найдена на странице.");

            // Act
            startButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent)); // Симулируем нажатие кнопки

            // Assert
            Assert.IsInstanceOfType(mainWindow.Content, typeof(GamePage), "Кнопка 'Начать игру' должна открывать страницу GamePage.");
        }
    }
}
