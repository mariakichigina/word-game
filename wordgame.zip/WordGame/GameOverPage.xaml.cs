﻿using System.Windows;
using System.Windows.Controls;

namespace WordGame
{
    public partial class GameOverPage : Page
    {
        private int finalScore;

        public GameOverPage(int score)
        {
            InitializeComponent();
            finalScore = score;
            ScoreText.Text = $"Ваш итоговый счёт: {finalScore} очков";
        }

        // Переход на первую страницу для начала новой игры
        private void RestartGame_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }
    }
}