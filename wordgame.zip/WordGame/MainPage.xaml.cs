﻿using System.Windows;
using System.Windows.Controls;

namespace WordGame
{
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void StartGame_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PlayerNameTextBox.Text))
            {
                MessageBox.Show("Введите имя игрока!");
                return;
            }

            string playerName = PlayerNameTextBox.Text;
            NavigationService.Navigate(new GamePage(playerName));
        }

        private void ViewLeaderboard_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new LeaderboardPage());
        }
    }
}