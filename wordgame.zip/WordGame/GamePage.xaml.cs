﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace WordGame
{
    public partial class GamePage : Page
    {
        private string playerName;
        private string randomLetters;
        private HashSet<string> usedWords = new HashSet<string>();
        private HashSet<string> dictionary = new HashSet<string>();
        private int score = 0;
        private int round = 1;
        private Random random = new Random();
        private const int totalRounds = 5;
        private const string LeaderboardFile = "leaderboard.txt";

        public GamePage(string name)
        {
            InitializeComponent();
            playerName = name;
            PlayerNameText.Text = $"Игрок: {playerName}";
            LoadDictionary();
            StartRound();
        }


// Метод для генерации 8 уникальных букв: 4 гласные и 4 согласные
private string GenerateUniqueLetters(int totalLetters)
    {
        // Определим списки гласных и согласных букв
        char[] vowels = { 'А', 'Е', 'Ё', 'И', 'О', 'У', 'Ы', 'Э', 'Ю', 'Я' };
        char[] consonants = { 'Б', 'В', 'Г', 'Д', 'Ж', 'З', 'К', 'Л', 'М', 'Н', 'П', 'Р', 'С', 'Т', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ' };

        // Генерация 4 случайных гласных
        List<char> selectedVowels = vowels.OrderBy(x => random.Next()).Take(4).ToList();

        // Генерация 4 случайных согласных
        List<char> selectedConsonants = consonants.OrderBy(x => random.Next()).Take(4).ToList();

        // Объединяем гласные и согласные буквы
        List<char> allLetters = selectedVowels.Concat(selectedConsonants).ToList();

        // Перемешиваем порядок букв
        return new string(allLetters.OrderBy(x => random.Next()).ToArray());
    }

    // Загружаем словарь
    private void LoadDictionary()
        {
            string dictionaryPath = ("C:\\Users\\Мария\\Downloads\\word_rus\\word_rus.txt");

            if (File.Exists(dictionaryPath))
            {
                dictionary = File.ReadAllLines(dictionaryPath)
                    .Select(word => word.Trim().ToUpper())
                    .ToHashSet();
            }
            else
            {
                MessageBox.Show("Файл словаря dictionary.txt не найден! Добавьте файл в папку приложения.");
            }
        }






        // Начинаем новый раунд
        private void StartRound()
        {
            if (round > totalRounds)
            {
                ShowLeaderboard(null, null);
                return;
            }

            // Генерация 4 гласных и 4 согласных
            randomLetters = GenerateUniqueLetters(8);

            // Очистка панели и добавление кнопок для букв
            LetterPanel.Children.Clear();
            foreach (char c in randomLetters)
            {
                var button = new Button
                {
                    Content = c.ToString(),
                    FontSize = 16,
                    Width = 40,
                    Height = 40,
                    Margin = new Thickness(6),
                    Background = new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 192, 203)), // Розовый цвет
                    Foreground = Brushes.Black, // Белый текст для контраста
                    BorderThickness = new Thickness(1)
                };
                button.Click += LetterButton_Click;
                LetterPanel.Children.Add(button);
            }

            RoundText.Text = $"Раунд: {round}/{totalRounds}";
            WordInput.Text = string.Empty;
            ResultText.Text = string.Empty;
            usedWords.Clear();

            // Отключаем кнопку "Следующий раунд" на последнем раунде
            NextRoundButton.IsEnabled = round < totalRounds;
        }

        private void ShowLeaderboard()
        {
            throw new NotImplementedException();
        }

 


        // Обработка клика по букве
        private void LetterButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            WordInput.Text += button.Content;
        }

        // Проверка введённого слова
        private void CheckWord_Click(object sender, RoutedEventArgs e)
        {
            string word = WordInput.Text.ToUpper();

            if (string.IsNullOrWhiteSpace(word))
            {
                ResultText.Text = "Введите слово!";
                ClearWordInput();
                return;
            }

            if (usedWords.Contains(word))
            {
                ResultText.Text = "Это слово уже использовано!";
                ClearWordInput();
                return;
            }

            if (!dictionary.Contains(word))
            {
                ResultText.Text = "Такого слова нет в словаре!";
                ClearWordInput();
                return;
            }

            usedWords.Add(word);
            score += word.Length;
            ResultText.Text = $"Слово зачтено! Счет: {score}";
            ClearWordInput();
        }

        private void GenerateBlurredLetters()
        {
            char[] letters = { 'А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ж', 'З', 'И', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т' };
            Random random = new Random();

            for (int i = 0; i < 6; i++) // Генерируем 6 размытых букв
            {
                TextBlock textBlock = new TextBlock
                {
                    Text = letters[random.Next(letters.Length)].ToString(),
                    FontSize = random.Next(80, 120),
                    Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromArgb(150, 192, 192, 192)),
                    Opacity = 0.3
                };

                textBlock.Effect = new System.Windows.Media.Effects.BlurEffect
                {
                    Radius = random.Next(8, 15)
                };

                // Позиция на Canvas
                Canvas.SetLeft(textBlock, random.Next(0, (int)this.ActualWidth - 100));
                Canvas.SetTop(textBlock, random.Next(0, (int)this.ActualHeight - 100));

                // Добавляем на Canvas
                BackgroundCanvas.Children.Add(textBlock);
            }
        }

        public GamePage()
        {
           InitializeComponent();
           GenerateBlurredLetters();
        }

        // Очистка текстового поля
        private void ClearWordInput()
        {
            WordInput.Text = string.Empty;
        }

        // Удаление последней буквы из строки ввода
        private void EraseLetter_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(WordInput.Text))
            {
                WordInput.Text = WordInput.Text.Substring(0, WordInput.Text.Length - 1);
            }
        }

        // Переход к следующему раунду
        private void NextRound_Click(object sender, RoutedEventArgs e)
        {
            round++;
            StartRound();
        }

        // Завершение игры и показ таблицы лидеров
        private void ShowLeaderboard(object sender, RoutedEventArgs e)
        {
            SaveScore();
            NavigationService.Navigate(new GameOverPage(score));
        }

        private void ResetGame()
        {
            throw new NotImplementedException();
        }

        // Сброс игры
        private void ResetGame(object sender, RoutedEventArgs e)
        {
            score = 0;
            round = 1;
            StartRound();
        }



        // Сохранение результата в таблицу лидеров
        private void SaveScore()
        {
            File.AppendAllText(LeaderboardFile, $"{playerName},{score}\n");
        }

        public bool IsValidWord(string v, string letters)
        {
            throw new NotImplementedException();
        }
    }
}
