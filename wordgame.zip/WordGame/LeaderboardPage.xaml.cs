﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace WordGame
{
    public partial class LeaderboardPage : Page
    {
        public LeaderboardPage()
        {
            InitializeComponent();
            LoadLeaderboard();
        }

        private void LoadLeaderboard()
        {
            var scores = new List<(string Name, int Score)>();
            if (File.Exists("leaderboard.txt"))
            {
                var lines = File.ReadAllLines("leaderboard.txt");
                foreach (var line in lines)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 2 && int.TryParse(parts[1], out int score))
                    {
                        scores.Add((parts[0], score));
                    }
                }
            }

            LeaderboardList.ItemsSource = scores
                .OrderByDescending(s => s.Score)
                .Select(s => new { s.Name, s.Score })
                .ToList();
        }

        private void BackToMain_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MainPage());
        }
    }
}